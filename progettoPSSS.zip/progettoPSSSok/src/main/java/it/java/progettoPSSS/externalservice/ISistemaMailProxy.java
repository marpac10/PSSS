package it.java.progettoPSSS.externalservice;

import java.rmi.Remote;

public interface ISistemaMailProxy extends Remote{
}