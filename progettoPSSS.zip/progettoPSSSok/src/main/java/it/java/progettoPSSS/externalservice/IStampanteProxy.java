package it.java.progettoPSSS.externalservice;

import java.rmi.Remote;

public interface IStampanteProxy extends Remote {
}