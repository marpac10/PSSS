package it.java.progettoPSSS.externalservice;

public class SistemaMailProxy implements ISistemaMailProxy {
}