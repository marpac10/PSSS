package it.java.progettoPSSS.externalservice;

public class StampanteProxy implements IStampanteProxy {
}