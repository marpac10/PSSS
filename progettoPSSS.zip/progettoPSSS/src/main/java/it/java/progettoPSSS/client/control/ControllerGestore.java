package it.java.progettoPSSS.client.control;

public class ControllerGestore {
}