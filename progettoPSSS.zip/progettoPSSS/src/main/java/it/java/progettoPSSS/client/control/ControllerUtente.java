package it.java.progettoPSSS.client.control;

import java.util.ArrayList;

import it.java.progettoPSSS.client.proxy.*;
import it.java.progettoPSSS.server.domain.*;

public class ControllerUtente {
	
	private static ControllerUtente istance = null;

	private ControllerUtente() {
		super();
	}

	public static ControllerUtente getIstance() {
		if (istance==null) {
			istance = new ControllerUtente();
		}
		return istance;
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public int login(String username, String password) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.login(username,password);
	}
	
	
	public boolean registrazione(String username, String password) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.registrazione(username,password);
	}
	
	

	
	public boolean pagamento(String carta, String cvv) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.pagamento(carta,cvv);
	}
	/**
	 * 
	 * @param sport
	 */
	public ArrayList<Campo> listaCampiDisponibili() {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.listaCampiDisponibili();
	}

	/**
	 * 
	 * @param campo
	 */
	public ArrayList<Prenotazione> listaPrenotazioniDisponibili(int id) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.listaPrenotazioniDisponibili(id);
	}

	/**
	 * 
	 * @param utente
	 * @param prenotazione
	 */
	public boolean prenotaCampo(Utente utente, Prenotazione prenotazione) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.prenotaCampo(utente, prenotazione);
	}

	/**
	 * 
	 * @param utente
	 */
	public ArrayList<Prenotazione> prenotazioniEffettuate(int id_utente) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.prenotazioniEffettuate(id_utente);
	}

	/**
	 * 
	 * @param utente
	 * @param prenotazione
	 */
	public boolean annullaPrenotazione(Prenotazione prenotazione, Utente utente) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.annullaPrenotazione(prenotazione, utente);
	}

	/**
	 * 
	 * @param utente
	 */
	public ArrayList<Ticket> listaTicket(int id_utente) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.listaTicket(id_utente);
	}

	/**
	 * 
	 * @param utente
	 */
	public int visualizzaPuntiPremium(int id_utente) {
		ClientProxy clientProxy = new ClientProxy();
		return clientProxy.visualizzaPuntiPremium(id_utente);
	}

	/**
	 * 
	 * @param ticket
	 */
	public void stampaTicket(Ticket ticket) {
		// TODO - implement ControllerCliente.stampaTicket
		throw new UnsupportedOperationException();
	}

}