package it.java.progettoPSSS.server.domain;

public class GestoreUtenti {
}