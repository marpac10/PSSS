package it.java.progettoPSSS.client.UI;

import java.awt.EventQueue;


import it.java.progettoPSSS.client.control.ControllerUtente;
import it.java.progettoPSSS.server.domain.*;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.util.TestUtils;

import javax.swing.JCheckBox;
import javax.swing.JTextField;

public class UtenteInterface {

	private JFrame frame;
	private Utente utente;
	JTextArea textAreaUsername;
	private JPasswordField passwordField;
	private JTable tableprenotazioni;
	JCheckBox chckbxPagaalcampo;
	JComboBox comboBoxcampi;
	JLabel lblNewLabelCodiceCarta;
	JTextArea textAreaCodiceCarta;
	JLabel lblcvv;
	JTextArea textAreacvv;
	JButton btnPaga ;
	int idsel;
	private JTable table;
	private JTable table_prenotazioni;
	private JTable table_ticket;
	JLabel lbldasettareUsername;
	JLabel lbldasettarePP;
	JLabel lbldasettareStato;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UtenteInterface window = new UtenteInterface();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
		
		
	}

	/**
	 * Create the application.
	 */
	public UtenteInterface() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 698, 479);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 662, 418);
		frame.getContentPane().add(tabbedPane);
		
		JPanel panelaccesso = new JPanel();
		tabbedPane.addTab("Accedi", null, panelaccesso, null);
		panelaccesso.setLayout(null);
		
		JLabel lblinserisciusername = new JLabel("Inserisci username");
		lblinserisciusername.setBounds(50, 93, 166, 64);
		panelaccesso.add(lblinserisciusername);
		
		textAreaUsername = new JTextArea();
		textAreaUsername.setBounds(195, 113, 123, 22);
		panelaccesso.add(textAreaUsername);
		
		JLabel lblinseriscipassword = new JLabel("Inserisci password");
		lblinseriscipassword.setBounds(50, 214, 140, 14);
		panelaccesso.add(lblinseriscipassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(195, 211, 123, 17);
		panelaccesso.add(passwordField);
		
		JButton btnaccedi = new JButton("Accedi");
		btnaccedi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				int id_utente = ControllerUtente.getIstance().login(textAreaUsername.getText(), passwordField.getText());
				
				if (id_utente != 0) {
					
					utente = new Utente();
					
					utente.setId(id_utente);
					utente.setUsername(textAreaUsername.getText());
					utente.setPassword(passwordField.getText());
					
					JOptionPane.showMessageDialog(null, "Accesso eseguito con successo");
					
					}
				
				else JOptionPane.showMessageDialog(null, "Accesso fallito, riprova");
				
				
				
				
				}
				
				
			});
		
		btnaccedi.setBounds(514, 301, 89, 23);
		panelaccesso.add(btnaccedi);
		
		JButton btnRegistrati = new JButton("Registrati");
		btnRegistrati.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if (ControllerUtente.getIstance().registrazione(textAreaUsername.getText(), passwordField.getText())) {
					JOptionPane.showMessageDialog(null, "Registrazione eseguita con successo");
					
				}
			
			else JOptionPane.showMessageDialog(null, "Registrazione fallita, riprova");
			
				}
				
		});
		
		
		btnRegistrati.setBounds(355, 301, 89, 23);
		panelaccesso.add(btnRegistrati);
		
		
		
		JPanel panelprenota = new JPanel();
		tabbedPane.addTab("Prenota un campo", null, panelprenota, null);
		panelprenota.setLayout(null);
		
		
		
	ArrayList<Campo> campi = ControllerUtente.getIstance().listaCampiDisponibili();
		
		comboBoxcampi = new JComboBox();
		comboBoxcampi.setBounds(152, 22, 495, 20);
		panelprenota.add(comboBoxcampi);
		
		for (Campo campo : campi) {
			comboBoxcampi.addItem(campo.toString());
		}
		
		
	
		
		
		JLabel lblselezionacampo = new JLabel("Seleziona un campo");
		lblselezionacampo.setBounds(31, 25, 111, 14);
		panelprenota.add(lblselezionacampo);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(20, 104, 627, 138);
		panelprenota.add(scrollPane);
		
		tableprenotazioni = new JTable();
		tableprenotazioni.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Data", "Ora"
			}
		));
		scrollPane.setViewportView(tableprenotazioni);
		
		JButton btnCercaPrenotazioni = new JButton("Cerca");
		btnCercaPrenotazioni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				idsel = comboBoxcampi.getSelectedIndex() + 1;
				
				ArrayList<Prenotazione> prenotazioni = ControllerUtente.getIstance().listaPrenotazioniDisponibili(idsel);
				DefaultTableModel model = (DefaultTableModel) tableprenotazioni.getModel();
				while(model.getRowCount() != 0)
				model.removeRow(0);
				
				for (Prenotazione prenotazione : prenotazioni) {
					model.addRow(new Object[] {prenotazione.getId()+"",prenotazione.getData()+"",prenotazione.getOra()+""});
				}
				
				
			}
		});
		
		chckbxPagaalcampo = new JCheckBox("Paga al campo");
		chckbxPagaalcampo.setBounds(140, 253, 97, 23);
		panelprenota.add(chckbxPagaalcampo);
		
		
		btnCercaPrenotazioni.setBounds(219, 53, 89, 23);
		panelprenota.add(btnCercaPrenotazioni);
		
		 lblNewLabelCodiceCarta = new JLabel("Inserisci codice carta");
		lblNewLabelCodiceCarta.setVisible(false);
		lblNewLabelCodiceCarta.setBounds(42, 303, 129, 14);
		panelprenota.add(lblNewLabelCodiceCarta);
		
		textAreaCodiceCarta = new JTextArea();
		textAreaCodiceCarta.setVisible(false);
		textAreaCodiceCarta.setBounds(219, 298, 111, 23);
		panelprenota.add(textAreaCodiceCarta);
		
		lblcvv = new JLabel("Inserisci cvv");
		lblcvv.setVisible(false);
		lblcvv.setBounds(42, 349, 100, 14);
		panelprenota.add(lblcvv);
		
		textAreacvv = new JTextArea();
		textAreacvv.setVisible(false);
		textAreacvv.setBounds(219, 344, 116, 19);
		panelprenota.add(textAreacvv);
		
		btnPaga = new JButton("Paga");
		btnPaga.setVisible(false);
		btnPaga.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (ControllerUtente.getIstance().pagamento(textAreaCodiceCarta.getText(), textAreacvv.getText())) {
				int riga = tableprenotazioni.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) tableprenotazioni.getModel();
				Integer idselezionato = Integer.parseInt((String)model.getValueAt(riga, 0));
				LocalDate dataselezionata = LocalDate.parse((String)model.getValueAt(riga, 1));
				LocalTime oraselezionata = LocalTime.parse((String)model.getValueAt(riga, 2));
				Prenotazione p = new Prenotazione();
				p.setId(idselezionato);
				p.setData(dataselezionata);
				p.setOra(oraselezionata);
				p.setDisponibile(true);
				p.setPagata(true);
				p.setid_campo(idsel);
				p.setid_utente(5);
				
				if(ControllerUtente.getIstance().prenotaCampo(utente, p)) {
					JOptionPane.showMessageDialog(null, "Pagamento effettuato con successo e prenotazione effettuata!");
					model.removeRow(riga);
				}
				else JOptionPane.showMessageDialog(null, "Errore nella prenotazione, riprova");
				}
				else JOptionPane.showMessageDialog(null, "Errore nel pagamento, riprova");
			}
				
				
				
			
		});
		btnPaga.setBounds(445, 345, 89, 23);
		panelprenota.add(btnPaga);
		
		
		
		JButton btnConfermaPrenotazione = new JButton("Conferma");
		btnConfermaPrenotazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxPagaalcampo.getModel().isSelected()) {
				int riga = tableprenotazioni.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) tableprenotazioni.getModel();
				Integer idselezionato = Integer.parseInt((String)model.getValueAt(riga, 0));
				LocalDate dataselezionata = LocalDate.parse((String)model.getValueAt(riga, 1));
				LocalTime oraselezionata = LocalTime.parse((String)model.getValueAt(riga, 2));
				Prenotazione p = new Prenotazione();
				p.setId(idselezionato);
				p.setData(dataselezionata);
				p.setOra(oraselezionata);
				p.setDisponibile(true);
				p.setPagata(false);
				p.setid_campo(idsel);
				p.setid_utente(5);
				
				if(ControllerUtente.getIstance().prenotaCampo(utente, p)) {
					JOptionPane.showMessageDialog(null, "Prenotazione confermata, dovrai pagare al campo");
					model.removeRow(riga);
				}
				else JOptionPane.showMessageDialog(null, "Errore nella prenotazione, riprova");
				}
				else {
					lblNewLabelCodiceCarta.setVisible(true);
					lblcvv.setVisible(true);
					textAreacvv.setVisible(true);
					textAreaCodiceCarta.setVisible(true);
					btnPaga.setVisible(true);
					
					
				}
				
				
			}
		});
		btnConfermaPrenotazione.setBounds(499, 253, 89, 23);
		panelprenota.add(btnConfermaPrenotazione);
		
		
		
		
		
		JPanel panelannulla = new JPanel();
		tabbedPane.addTab("Annulla Prenotazione", null, panelannulla, null);
		panelannulla.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(64, 65, 546, 181);
		panelannulla.add(scrollPane_1);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Data", "Ora", "Campo", "Pagata"
			}
		));
		scrollPane_1.setViewportView(table);
		
		JLabel lblAnnullaPrenotazione = new JLabel("Seleziona la prenotazione da annullare:");
		lblAnnullaPrenotazione.setBounds(64, 25, 280, 14);
		panelannulla.add(lblAnnullaPrenotazione);
		
		JButton btnAggiornaAnnulla = new JButton("Aggiorna");
		btnAggiornaAnnulla.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
				
				ArrayList<Prenotazione> prenotazioni = ControllerUtente.getIstance().prenotazioniEffettuate(utente.getId());
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				while(model.getRowCount() != 0)
				model.removeRow(0);
				
				for (Prenotazione prenotazione : prenotazioni) {
					String pag = new String();
					if (prenotazione.isPagata()) pag = "Si";
					else pag = "No";
					model.addRow(new Object[] {prenotazione.getId()+"",prenotazione.getData()+"",prenotazione.getOra()+"",prenotazione.getid_campo()+"",pag});
				}
				
			
				
				
			}
		});
		btnAggiornaAnnulla.setBounds(416, 21, 89, 23);
		panelannulla.add(btnAggiornaAnnulla);
		
		JButton btnAnnulla = new JButton("Conferma");
		btnAnnulla.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int riga = table.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				Integer idselezionato = Integer.parseInt((String)model.getValueAt(riga, 0));
				LocalDate dataselezionata = LocalDate.parse((String)model.getValueAt(riga, 1));
				LocalTime oraselezionata = LocalTime.parse((String)model.getValueAt(riga, 2));
				Integer id_campo_selezionato = Integer.parseInt((String)model.getValueAt(riga, 3));
				boolean pagata_selezionata;
				if (model.getValueAt(riga, 4).equals("Si")) pagata_selezionata=true;
				else pagata_selezionata = false;
				Prenotazione p = new Prenotazione();
				p.setId(idselezionato);
				p.setData(dataselezionata);
				p.setOra(oraselezionata);
				p.setDisponibile(false);
				p.setPagata(pagata_selezionata);
				p.setid_campo(id_campo_selezionato);
				p.setid_utente(utente.getId());
				if(ControllerUtente.getIstance().annullaPrenotazione(p,utente)) {
					JOptionPane.showMessageDialog(null, "Annullamento confermato");
					model.removeRow(riga);
				}
				else JOptionPane.showMessageDialog(null, "Errore nell'annullamento, riprova");
				
				
				
				
			}
		});
		btnAnnulla.setBounds(461, 257, 89, 23);
		panelannulla.add(btnAnnulla);
		
		JPanel panelprofilo = new JPanel();
		tabbedPane.addTab("Visualizza profilo", null, panelprofilo, null);
		panelprofilo.setLayout(null);
		
		
		
		JLabel lblUsernameProfilo = new JLabel("Username");
		lblUsernameProfilo.setBounds(34, 77, 98, 14);
		panelprofilo.add(lblUsernameProfilo);
		
		lbldasettareUsername = new JLabel("");
		lbldasettareUsername.setBounds(211, 77, 127, 14);
		panelprofilo.add(lbldasettareUsername);
		
		JLabel lblPrenotazioniProfilo = new JLabel("Prenotazioni effettuate");
		lblPrenotazioniProfilo.setBounds(34, 128, 133, 14);
		panelprofilo.add(lblPrenotazioniProfilo);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(206, 125, 384, 67);
		panelprofilo.add(scrollPane_2);
		
		table_prenotazioni = new JTable();
		table_prenotazioni.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Data", "Ora", "Campo", "Pagata"
			}
		));
		scrollPane_2.setViewportView(table_prenotazioni);
		
		JLabel lblPuntiPremium = new JLabel("Punti premium");
		lblPuntiPremium.setBounds(49, 251, 98, 14);
		panelprofilo.add(lblPuntiPremium);
		
		JLabel lblStato = new JLabel("Stato");
		lblStato.setBounds(334, 251, 46, 14);
		panelprofilo.add(lblStato);
		
		lbldasettarePP = new JLabel("");
		lbldasettarePP.setBounds(167, 251, 55, 14);
		panelprofilo.add(lbldasettarePP);
		
		lbldasettareStato = new JLabel("");
		lbldasettareStato.setBounds(450, 251, 127, 14);
		panelprofilo.add(lbldasettareStato);
		
		JLabel lblTicket = new JLabel("Ticket accumulati");
		lblTicket.setBounds(32, 306, 115, 14);
		panelprofilo.add(lblTicket);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(206, 306, 384, 73);
		panelprofilo.add(scrollPane_3);
		
		table_ticket = new JTable();
		table_ticket.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Data rilascio", "Ora rilascio", "Valore"
			}
		));
		scrollPane_3.setViewportView(table_ticket);
	
	
	JButton btnAggiornaProfilo = new JButton("Aggiorna");
	btnAggiornaProfilo.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			
			lbldasettareUsername.setText(utente.getUsername());
			ArrayList<Prenotazione> prenotazioni = ControllerUtente.getIstance().prenotazioniEffettuate(utente.getId());
			int punti = ControllerUtente.getIstance().visualizzaPuntiPremium(utente.getId());
			lbldasettarePP.setText((Integer.toString(punti))); 
			ArrayList<Ticket> ticket = ControllerUtente.getIstance().listaTicket(utente.getId());
			if (punti>=100) lbldasettareStato.setText("PREMIUM");
			else lbldasettareStato.setText("STANDARD");
			
			DefaultTableModel modelp = (DefaultTableModel) table_prenotazioni.getModel();
			while(modelp.getRowCount() != 0)
			modelp.removeRow(0);
			
			for (Prenotazione prenotazione : prenotazioni) {
				String pag = new String();
				if (prenotazione.isPagata()) pag = "Si";
				else pag = "No";
				modelp.addRow(new Object[] {prenotazione.getId()+"",prenotazione.getData()+"",prenotazione.getOra()+"",prenotazione.getid_campo()+"",pag});
			}
			
			DefaultTableModel modelt = (DefaultTableModel) table_ticket.getModel();
			while(modelt.getRowCount() != 0)
			modelt.removeRow(0);
			
			for (Ticket t : ticket) {
				modelt.addRow(new Object[] {t.getId()+"",t.getData()+"",t.getOra()+"",t.getValore()});
			}
			
			
			
			

			
			
			
			
			
		}
	});
	btnAggiornaProfilo.setBounds(455, 11, 89, 23);
	panelprofilo.add(btnAggiornaProfilo);
}
}
